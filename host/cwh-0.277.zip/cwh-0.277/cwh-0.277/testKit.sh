#!/bin/bash

./start.sh "area515/Creation-Workshop-Host" "TestKit"
