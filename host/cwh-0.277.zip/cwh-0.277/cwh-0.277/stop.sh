#!/bin/bash

pkill -f org.area515.resinprinter.server.Main
